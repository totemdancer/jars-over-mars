from pithos.application import main

main()
