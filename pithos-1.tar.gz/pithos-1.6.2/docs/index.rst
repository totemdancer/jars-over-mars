.. Pithos documentation master file, created by
   sphinx-quickstart on Mon Sep 15 20:13:58 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Pithos's documentation!
==================================

Pandora
-------

.. autoclass:: pithos.pandora.Pandora
   :members:
   :undoc-members:

.. autoclass:: pithos.pandora.Station
   :members:
   :undoc-members:

.. autoclass:: pithos.pandora.Song
   :members:
   :undoc-members:

.. autoclass:: pithos.pandora.SearchResult
   :members:
   :undoc-members:

.. autoclass:: pithos.pandora.PandoraError
   :members:
   :undoc-members:

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

